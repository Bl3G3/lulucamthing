import time
from datetime import datetime
import subprocess
from os import listdir
from os import system
from os.path import isfile, join

debug = False


def reload_config():
    file = open("cam.properties")
    lines = file.readlines()
    conf = {}
    for line in lines:
        res = line.split('=')
        conf[res[0]] = res[1].strip()
    file.close()
    return conf


def get_camera_command(cam_config):
    return f"""libcamera-vid -t {cam_config.get('DURATION', '120000')} -o {cam_config.get("OUT_FOLDER", "~/") + datetime.today().strftime('%Y-%m-%d_%H:%M:%S') + '.h264'} --framerate {cam_config.get('FRAMERATE', 2)}"""


def get_convert_command(cam_config, file):
    outfile = file.replace("h264", "mp4")
    return f"""ffmpeg -framerate {cam_config.get('FRAMERATE', 2)} -i {cam_config.get("OUT_FOLDER", "~/")}/{file} -c copy {cam_config.get("OUT_FOLDER", "~/")}/{outfile}"""


def convert_existing_files(cam_config):
    # get all the fancy files
    only_files = [f for f in listdir(cam_config.get("OUT_FOLDER", "~/").strip()) if
                  isfile(join(cam_config.get("OUT_FOLDER", "~/").strip(), f))]
    # get only files not converted yet
    to_be_converted = [f for f in only_files if ".h264" in f and f.replace("h264", "mp4") not in only_files]
    for file in to_be_converted:
        system(get_convert_command(cam_config, file))


if __name__ == '__main__':
    camera_process = None

    if debug:
        config = reload_config()
        print("test")
        # get_convert_command(config, "lulu")
    else:
        while True:
            config = reload_config()
            convert_existing_files(config)
            enabled = config.get("RASPI_CAM_ENABLED")
            if enabled == "true":
                command = get_camera_command(config)
                if camera_process is None:
                    camera_process = subprocess.Popen("exec " + command, stdout=subprocess.PIPE, shell=True)
            else:
                if camera_process is not None:
                    camera_process.kill()
                time.sleep(5)
